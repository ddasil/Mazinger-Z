from django.apps import AppConfig


class LyricsgenConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "lyricsgen"
